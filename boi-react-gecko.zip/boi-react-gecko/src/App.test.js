import { render, screen } from '@testing-library/react';
import GeckoCoins from './GeckoCoins';

test('renders learn react link', () => {
  render(<GeckoCoins />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
