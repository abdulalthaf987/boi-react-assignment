import React, {Component} from 'react';
import axios from 'axios';

const getGeckoMarketsAPI = axios.create({
  baseURL : 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=eur&order=market_cap_desc&per_page=10&page=1&sparkline=false'
});

const domain = 'https://api.coingecko.com';
const apiVersion = '/api/v3/';

function getCoinsApiInfo(id){
  axios.get(`https://api.coingecko.com/api/v3/coins/${id}`).then(res => {
    console.log(res.data.name);
    console.log(res.data.symbol);
    console.log(res.data.hashing_algorithm);
    console.log(res.data.description);
    console.log(res.data.market_cap_rank);
    console.log(res.data.homepage);
    console.log(res.data.genesis_date);
  }).catch(error => {
    console.log(error)
   })
}

class GeckoCoins extends Component{

  constructor(props) {
    super(props);
    this.state = {
      GeckoMarkets: []
    };
  }  

  componentDidMount(){
    getGeckoMarketsAPI.get('/').then(response => {
    this.setState({GeckoMarkets : response.data});
    })
    .catch(error => {
     console.log(error)
    })
  }  

  render(){
    const renderGeckoMarket = this.state.GeckoMarkets.map((geckoElement) => {
      return(
        <tr key={geckoElement.id}>
          <td><img src={geckoElement.image} alt={geckoElement.name}/></td>
          <td>{geckoElement.name}</td>
          <td>{geckoElement.symbol}</td>
          <td>{geckoElement.current_price}</td>
          <td>{geckoElement.high_24h}</td>
          <td>{geckoElement.low_24h}</td>
          <td><a href='#' onClick={() => getCoinsApiInfo(geckoElement.id)}>Coin Info</a></td>
      </tr>
    )
  });

  return(
    <table className="table table-striped">
        <thead>
            <tr>
            <th>Image</th>
            <th>Name</th>
            <th>symbol</th>
            <th>Current Price</th>
            <th>High 24 hour price</th>
            <th>Low 24 hour price</th>
            </tr>
        </thead>
        <tbody>     
            {renderGeckoMarket}
        </tbody>
    </table>    
    )
  }
}

export default GeckoCoins;